
clc;
clear;


testing_dataset = 'real';
testing_names = {'LPN', 'CVPR', 'PReNet', 'Syn2Real', 'TIP'};

brisque_model = brisqueModel();
OutputDir = '/home/matlab/Documents/MATLAB/code/results/no_ref_results/';

for algo_index = 1:5
    
    img_path_list1 = [];
    
    file_path1= ['/home/matlab/Documents/MATLAB/code/results/', testing_dataset ,'/' ,testing_names{algo_index}, '/' ]

    img_path_list1 = [dir(strcat(file_path1,'*.png'));dir(strcat(file_path1,'*.jpg'))];

    img_num = length(img_path_list1);

    I = cell(img_num,1);
    
    S=[];
    B=[];
    N=[];


    SS = 0;
    BR = 0;
    NI = 0;


    output_file_name = [OutputDir, testing_dataset, '_', testing_names{algo_index}, '_result.csv'];


    

    if img_num > 0
        for j = 1:img_num
             image_name1 = img_path_list1(j).name;

             input_rain =  imread(strcat(file_path1,image_name1));   

            I{j}=image_name1;

            BRISQUE = brisque(input_rain,brisque_model);

        NIQE = niqe(input_rain);


        SSEQ = no_reference_metric(input_rain, 'SSEQ');

    B=[B,eval(num2str(BRISQUE))]; 
    S=[S,eval(num2str(SSEQ))]; 

    N=[N,eval(num2str(NIQE))];  




        SS = SS + SSEQ;

        NI = NI + NIQE;


        end
    end
    
    columns = {'imagename', 'BRISQUE' 'NIQE', 'SSEQ'};
S=S'
B=B'
N=N'


data = table(I,B, N, S,'VariableNames',columns);

average_brisque = mean(B)
average_niqe = mean(N)
average_sseq = mean(S)

additional_data= {'average', average_brisque, average_niqe, average_sseq};
            
data = [data;additional_data]
    
writetable(data, output_file_name);

disp(['output ', output_file_name ])

end


 


