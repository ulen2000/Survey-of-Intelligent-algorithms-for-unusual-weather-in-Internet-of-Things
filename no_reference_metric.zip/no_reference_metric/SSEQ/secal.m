function e = secal(im)
    e=entropy(im);
end

